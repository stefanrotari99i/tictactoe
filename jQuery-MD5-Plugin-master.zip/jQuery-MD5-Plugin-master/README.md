jQuery MD5 Plugin
=================

string jQuery.MD5( string )
input string and return string
The $.MD5() function convert string to MD5

(c) 2012 Winai Reungjam
licensed under the MIT licenses.

This function orginally get from the WebToolkit and rewrite for using as the jQuery plugin.
MD5 (Message-Digest Algorithm)
http://www.webtoolkit.info/

